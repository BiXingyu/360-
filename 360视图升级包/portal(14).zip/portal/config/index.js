/*
 * @Date: 2022-03-22 16:37:23
 * @LastEditors: Zhibing Wang
 * @LastEditTime: 2022-12-15 13:27:06
 * @FilePath: \winning-platform-360-web\public\config\index.js
 */
const config = {
  // 是否开启调试模式
  debuggerBig: true,
  project: {
    name: "mobile360",
  },
  // 本地包 数据服务平台地址  /c
  // baseUrl1: "http://172.23.18.91:8762/", // api接口ip地址   谭天本地172.23.18.91
  // baseUrl1: "http://127.0.0.1:8762/", // api接口ip地址   本地包 1(配合xshell连复星正式环境的地址)
  // baseUrl1: "http://10.10.50.130:8762/", // 测试环境UAT  2
  // baseUrl1: "http://172.17.0.116:8762/", // 116环境
  baseUrl1: "http://10.8.16.63:8762/",
  // baseUrl1: "http://10.11.11.61:8762/", // 现场 的正式环境  3

  // 60地址
  // baseUrl2: "http://172.23.18.91:8201/", // api接口ip地址 开发环境
  // baseUrl2: "http://127.0.0.1:8764/", // 正式环境xshell代理过去的  1
  // baseUrl2: "http://10.10.50.130:8764/", // 测试环境UAT  2
  // baseUrl2: "http://172.16.9.92:8201/", // "hdw/", // 116环境
  baseUrl2: "http://10.8.16.61:8201/",
  // baseUrl2: "http://10.11.11.59:8764/", // 现场 的正式环境  3

  casLoginUrl: "http://172.17.1.205:8200/casServer/login", // cas登录地址（根据现场修改ip和端口）
  casCookie: "JSESSIONID-hirc",

  // **兼容多院区的图片 北大的需要配置这个，复星的不配置默认有
  // todo..后期根据不同医院自定义对应的尺寸
  // HospitalMessage:{
  //   name:'北京大学人民医院',
  //   copName:"Peking University People's Hospital",
  //   // 登录页logo
  //   loginCss:{
  //     width:'2.26rem', //尺寸除以192
  //     height:'',
  //   },
  //   // 主页logo
  //     layoutCss:{
  //     width:'0.22rem', //尺寸除以192
  //     height:'',
  //   }
  // }

  // 116环境的作为未来公版的
  // HospitalMessage: {
  //   name: '卫宁健康',
  //   copName: "Winning Health",
  //   // 登录页logo
  //   loginCss: {
  //     width: '0.56rem', // 尺寸除以192
  //     height: '',
  //   },
  //   // 主页logo
  //   layoutCss: {
  //     width: '0.62rem', // 尺寸除以192
  //     height: '',
  //   }
  // }

};

config.authAdminPath = config.baseUrl1 + "/authAdmin/login"; // 统一权限管理系统登录地址
window.CONFIG = config;
